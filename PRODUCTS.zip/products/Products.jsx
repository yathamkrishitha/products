import React,{ useEffect, useState } from 'react';

import 'bootstrap';
import { Link,useNavigate } from 'react-router-dom';
function Products(){
  const [product, setProduct] = useState([]);
  const [category,setCategory] = useState("all");
  const [loading,setLoading]=useState(false);
  
  const handleproducts=async()=>{
    setLoading(true);
    const token=localStorage.getItem('token');
    let url = "http://localhost:5000/api/products";

    if(category == "all"){
      const fetching=await fetch(url,{
        method:"GET",
        headers:{
          'Content-Type':'application/json',
          "Authorization":`Bearer ${token}`
          
        },
      });

      const fetched=await fetching.json();

      setProduct(fetched);
    }
    else{
      const filterurl =`https://fakestoreapi.com/products/category/${category}`;
      const fetching=await fetch(filterurl,{
        method:"GET",
        headers:{
          'Content-Type':'application/json',
          "Authorization":`Bearer${token}`
        },
      });

      const fetched=await fetching.json();

      setProduct(fetched);
    }
    setLoading(false);
}
const navigate = useNavigate()
useEffect(() => {
  const token=localStorage.getItem("token")
  if(!token){
    navigate('/')
  }
  handleproducts()
}, [category]);
const handlelogout = () =>{
  localStorage.removeItem("token")

  navigate('/')
} 
 return (
    <>
    {
      loading?(<h1>Loading....</h1>): <div>
      <h1 >Products Page</h1>
      <button onClick={()=>handlelogout()}>Logout</button>
      <div>
        <button className='border border-2 border-dark btn btn-md btn-light me-2'onClick={() => setCategory("all")}>All</button>
        <button className='border border-2 border-dark btn btn-md btn-light me-2'onClick={() => setCategory("men's clothing")}>Men's</button>
        <button className='border border-2 border-dark btn btn-md btn-light me-2'onClick={() => setCategory("women's clothing")}>Women's</button>
        <button className='border border-2 border-dark btn btn-md btn-light me-2'onClick={() => setCategory("jewelery")}>Jewellery</button>
        <button className='border border-2 border-dark btn btn-md btn-light'onClick={() => setCategory("electronics")}>Electronics</button>
      <div className="row">
      {
        product.map((item,index)=>(
          
            <div className="col-3 text-center" key={index}> 
              <div className='border d-flex flex-column align-items-center m-2 p-3'>
            <Link to={`/Products/${item.id}`}>
            <h5>{item.title}</h5>
            </Link>
            <div className="fw-bold fs-5">$ {item.price}</div>
            <div className='line'>
              <img src={item.image} alt="" width='90px' height='100px' />
            </div>
            <button className="btn btn-warning mt-3">Add to Cart</button>
              </div>
            </div>

         
        ))
      }
    </div>
    </div>
    </div>
    }
    </>
  )
}
export default Products;
// import React, { useEffect } from "react";
// import { useState } from "react";
// import { Link ,useNavigate} from "react-router-dom";
// function Products() {
//   const [product, setProduct] = useState([]); 
//   const [category, setCategory] = useState("all");
//   const [loading, setLoading] = useState(false);
//   const fetchproducts = async () => {
//     setLoading(true);
//     let url = "https://fakestoreapi.com/products"
//     if (category == "all") {
//       const fetching = await fetch(url)
//       const fetched = await fetching.json();
//       setProduct(fetched)
//     } else {
//       const newUrl = `https://fakestoreapi.com/products/category/${category}`;
//       const fetching = await fetch(newUrl)
//       const fetched = await fetching.json();
//       setProduct(fetched)
//     }
//     setLoading(false);
//   }
//   // fetchproducts();
//   const navigate=useNavigate()
//   useEffect(
//     () => { 
//       const token=localStorage.getItem('token')
//       if(!token){
//         navigate('/')
//       }
      
//         fetchproducts()
  
//      }, [category]
//   )
//   const handlelogout=()=>{
//     localStorage.removeItem('token')
//     navigate('/')
//   }
//   return (
//     <>
//       {loading ? 
//         <h1>loading.....</h1>
//        : (
//         <div>
//           <h1>Products Page</h1>
//           <button onClick={()=>handlelogout()}>Log out</button>
//           <div>
//             <button className="me-2 btn btn-dark" onClick={() => setCategory("all")}>All</button>
//             <button className="me-2 btn btn-dark" onClick={() => setCategory("men's clothing")}>Men's Clothing</button>
//             <button className="me-2 btn btn-dark" onClick={() => setCategory("women's clothing")}>Women's clothing</button>
//             <button className="me-2 btn btn-dark" onClick={() => setCategory("jewelery")}>Jewelery</button>
//             <button className="me-2 btn btn-dark" onClick={() => setCategory("electronics")}>Electronics</button>
//             <div className="row">
//               {
//                 product.map((item, index) => (
//                   <div className="col-3 text-center" key={index}>
//                     <div className="border" style={{ height: "250px" }}>
//                       {/* <div className="h-25 overflow-hidden mb-2"><b>{item.title}</b></div> */}
//                       <Link to={`/products/${item.id}`} className="h-25 overflow-hidden mb-2">
//                         <h5>{item.title}</h5>
//                       </Link>
//                       <div> <img src={item.image} width="150px" height="70px" /></div>
//                       <div className="mt-4">${item.price}</div>
//                       <button className="btn btn-warning mt-3">Add to cart</button>
//                     </div>
//                   </div>
//                 ))
//               }
//             </div>
//           </div>
//         </div>)
//       }
//     </>
//   )
// }
// export default Products;