const User=require("../models/userModel")
const bcrypt=require("bcrypt")
const jwt=require("jsonwebtoken")
const express=require("express")
const router=express.Router()
router.post("/login",async(req,res)=>{
    try{
        const {username,password}=req.body;
        const isValidUser= await User.findOne({username});
    
        if (!isValidUser){
            return res.status(400).json({message:"invalid username"})
        }
        const isMatch=await bcrypt.compare(password, isValidUser.password)
        
        if (!isMatch){
            return res.status(400).json({message: "invalid password"})
        }
        // console.log(isValidUser,'valid')
        
        const token=jwt.sign(
            {
                userId: isValidUser._id, 
                username:isValidUser.username
            },
            process.env.SECRET_KEY,
            {
                expiresIn:'1h'
            }
        )
        return res.status(200).json({
            token:token,
            message:"user is verified"
        })
        console.log(req.body,"request of login")
        res.send("we got the request")
    }catch(err){
        res.status(500).json({
            // message:err.message
        })
    }
})
router.post("/register",async(req,res)=>{
    try{
        console.log(req.body,"request of register")
    const {username,password}=req.body;
    const saltRounds=10;
    const hashPassword= await bcrypt.hash(password,10)
    // console.log(hashPassword,"pass")
    const newUser=new User({username,password:hashPassword });
    const databaseUser=await newUser.save()
    res.send(databaseUser)
    }catch(err){
        res.status(500).json({
            message : err.message
        })
    }
})
module.exports=router;