
import { useState,useEffect  } from "react";
import { Link,useNavigate} from 'react-router-dom';
function Login() {
    const [username,setUsername] = useState('');
    const [password,setPassword] = useState('');
    const [isvaliduser,setIsvaliduser] = useState(true);

    
    
    
    function handleUserName(event){
        setUsername(event.target.value)   
    }
    function handlePassword(event){
        setPassword(event.target.value)   
    }
    const navigate = useNavigate();
    useEffect(()=>{
      const token=localStorage.getItem('token');
      if(token){
        navigate('/')
      }
    },[])
    
    const handleSubmit = async () => {
      // const token=localStorage.getItem('token');
        const response=await fetch("http://localhost:5000/api/auth/login",{
            method:"POST",
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify({username,password})
        });
          const data=await response.json();
        //   console.log("login successfully",data)
          if(data.token){
            navigate('/products');
          }else{
            navigate('/register')
          }
          localStorage.setItem('token',data.token)
          console.log("login successfully",data);
    }
  return (
    <div className="logo">
        <h1>Login-Page</h1>
        <span>Username: </span>
        <input type="text" placeholder="Enter User Name" id="user"
            onChange={(event)=> handleUserName(event)}
        />
        <br /><br />
        <span>Password: </span>
        <input type="password" placeholder="Enter password"
           onChange={(event)=> handlePassword(event)}
        />
        <br />
        <a href="/register" className="mx-3">Register</a>
        <Link to={'/register'}>Register</Link>
        <button className="btn btn-primary m-3" onClick={() => handleSubmit()}>Submit</button>
    </div>
  );
}

export default Login;