// import React from 'react'
// import { useParams } from 'react-router-dom';
// import { useState,useEffect } from 'react';
// function ProductSpecific(){
//     const {index}=useParams();
//      const [product, setProduct] = useState([]);
//      const [loading,setLoading]=useState(false)
//      const handleproducts=async()=>{
//         setLoading(true)
//         let url = `https://fakestoreapi.com/products/${index}`;
//         const data=await fetch(url);

//         const fetched=await data.json();
//         setProduct(fetched)
//         setLoading(false)
//      }
//      console.log(product,"product")

//      useEffect(()=>{
//          handleproducts()
//      },[]
//     )
//     return(
//         <div className="border w-50 m-5 ">
//            <h5>{product.title}</h5>
//            <img src={product.image} className='ms-4' alt="image"  height="100px" width="100px"/>
//            <h3>${product.price}</h3>
//            <div>{product.description}</div>
//        </div>
//     )
// }
// export default ProductSpecific;
import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import {useState} from "react";
function Productspecific(){
    const {index}=useParams();
    const [product, setProduct] = useState({});
    const [loading,setLoading] = useState(false);
    const fetchproducts = async () => {
        setLoading(true);
        let url =`https://fakestoreapi.com/products/${index}`;
         
          const fetching = await fetch(url)
          const fetched = await fetching.json();
          setProduct(fetched)
          setLoading(false);
        
      }
      useEffect(
        ()=>{fetchproducts()},[]
      )
    return(

        <div className="border w-50 ms-5 card shadow-sm">
            <h1 className="card-title">{product.title}</h1>
            <div className="d-flex flex-column justify-content-center align-items-center">
              <img src={product.image} className="ms-4" height="100px" width="100px"/>
              <h3>${product.price}</h3>
            </div>
            
            <div>{product.description}</div>
            
        </div>
    )
}
export default Productspecific;