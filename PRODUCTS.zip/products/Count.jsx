import {BrowserRouter,Routes,Route} from 'react-router-dom';
import { useState } from 'react'
// import '../node_modules/bootstrap/dist/css/bootstrap.css'
// import '../node_modules/bootstrap/dist/js/bootstrap.js'

// import './App.css'
// import App from './App'
// import Products from './Products'
function Count() {
  const [Count,setCount]=useState(0)
  const handleIncrement = () => {
    setCount(Count+1);
  }
  const handleDecrement = () => {
    setCount(Count-1);
  }
  const handleReset = () => {
    setCount(0);
  }

  return (
    <>
    <h1>counter:   {Count}</h1>
    <button onClick={() => handleIncrement()}>Increment</button>
    <button onClick={() => handleDecrement()}>Decrement</button>
    <button onClick={() => handleReset()}>Reset</button>
    </>
  );
}

export default Count;
