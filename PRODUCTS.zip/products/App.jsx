import {BrowserRouter,Routes,Route} from 'react-router-dom';

import React from "react";
import { useState } from "react";
import Products from './Products';
import Login from './assets/Login';
import Count from './assets/Count';
import Register from './assets/Register';
import ProductSpecific from './assets/ProductSpecific';
import TodoApplication from './assets/TodoApplication';
function App(){
  return(
    <BrowserRouter>
      <Routes>
        <Route path="/products" element={<Products/>} />
        <Route path="/products/:index" element={<ProductSpecific/>} />
        
        <Route path="/register" element={<Register/>} />
        <Route path="/" element={<Login/>} />
        <Route path="/count" element={<Count/>} />
        <Route path="/todo" element={<TodoApplication/>} />
        
      </Routes>
    </BrowserRouter>
    )
}
export default App;
