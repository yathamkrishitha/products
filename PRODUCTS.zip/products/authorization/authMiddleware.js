const jwt=require('jsonwebtoken');

const verifyToken=(req,res,next) => {
   try{
    console.log(req.headers.authorization,"request of frontend")
    const authHeader = req.headers.authorization;
    const token = authHeader.split(" ")[1]
    console.log(token,"token") 
    jwt.verify(token,process.env.SECRET_KEY,(err,decoded) => {
        if(err){
            return res.status(403).json({message:"token is required"})
        }
    })
    next()
   }catch(err){
    res.status(500).json({message:"unauthorized"})
   }
    
   

}
module.exports=verifyToken; 