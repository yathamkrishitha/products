const mongoose=require('mongoose')
const express = require('express');
const app = express();
const cors=require("cors")
const authRoutes=require('./authorization/authentication')
const todoRoutes=require("./routes/todoRoutes")
const productRoutes=require('./routes/productRoutes');
const verifyToken = require('./authorization/authMiddleware');
require('dotenv').config()
app.use(express.json())
app.use(cors())
const LocalPORT=process.env.PORT || 6000
console.log(LocalPORT,"port")
mongoose.connect(process.env.MONGO_URI)
    .then(()=>console.log("mongo db connected successfully"))
    .catch((error)=>console.log("error in mongodb connection",error))
    // console.log(process.env.MONGO_URI)

app.listen(LocalPORT,()=>{
    
    console.log(`backend is running at ${LocalPORT}`)
})
app.set("view engine",'ejs')

app.get("/",(req,res) =>{
    // res.send("hey this is response from backend")
    res.render("index",{aaaaa:"this message is a thikka"})
})
app.use('/api/auth',authRoutes)
app.use('/api/todo',todoRoutes)
app.use('/api/products',verifyToken,productRoutes)

app.use((req,res) =>{
    res.render("404")
})