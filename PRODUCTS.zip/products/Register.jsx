
import { useState  } from "react";
import { Link,useNavigate } from 'react-router-dom';

function Login() {
    const [username,setUsername] = useState('');
    const [password,setPassword] = useState('');
    const [isvalidUser,setIsValidUser] = useState(true)
    console.log(username,"username");
    console.log(password,"password");
    
    function handleUserName(event){
        setUsername(event.target.value)   //username
    }
    function handlePassword(event){
        setPassword(event.target.value)   //password
    }
    const Navigate=useNavigate()
    const handleSubmit = async () =>{
        const response= await fetch("http://localhost:5000/api/auth/register",{
        method:"POST",
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({username, password})
    })
        Navigate('/')
        const data=await response.json();
        console.log("data registered successfully",data)
    }
  return (
    <div className="logo">
        <h1>Register Page</h1>
        <span>UserName: </span>
        <input type="text" placeholder="Enter User Name" id="user"
            onChange={(event)=> handleUserName(event)}
        />
        <br /><br />
        <span>Password: </span>
        <input type="password" placeholder="Enter User Name"
           onChange={(event)=> handlePassword(event)}
       
        />
        <br />
        <a href="/register" className="mx-3">Register</a>
        <Link to={'/' }>link to Login</Link>
        <button className="btn btn-primary m-3" onClick={()=> handleSubmit()}>Submit</button>
    </div>
  );
}

export default Login;